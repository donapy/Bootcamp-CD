/*
Fragmento de código 1
function muestraInformaciónContacto() {
    var auntContactInfo = ["Paula", "Smith", "Calle Principal 1234", "St. Louis", "MO", 12345];
    console.log(auntContactInfo);
}

----------------------------------------------------------
auntContactInfo             |           Paula
                            |           Smith
                            |           Calle principal 1234
                            |           St. Louis
                            |           MO
                            |           12345


#################################################################

Fragmento de código 2
function muestraListaDeCompras() {
    var produce = ["manzanas", "naranjas"];
    var frozen = ["brócoli", "helado"];
    frozen.push("croqueta de papa");
    console.log(frozen);
}

----------------------------------------------------------
frozen                      |           brocoli
                            |           helado
                            |           croqueta de papa


#################################################################

Fragmento de código 3
var movieLibrary = ["Bambi", "E.T.", "Toy Story"];
movieLibrary.push("Zoro");
movieLibrary[1] = "Beetlejuice";
console.log(movieLibrary);

----------------------------------------------------------
movieLibrary                |           ["Bambi", "E.T.", "Toy Story"]
                            |           ["Bambi", "E.T.", "Toy Story", "Zoro"]
                            |           ["Bambi", "BeetleJuice", "Toy Story"]



*/
